import { Component } from '@angular/core';

@Component({
  selector: 'app-work-on-progress',
  imports: [],
  templateUrl: './work-on-progress.component.html',
  styleUrl: './work-on-progress.component.css',
})
export class WorkOnProgressComponent {
  underDevelopment: string = 'assets/gifs/dev.gif';
}
