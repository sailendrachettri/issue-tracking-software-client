export const ADD_CONTACT_URL: string = '/api/contacts/save-contact-forms';
export const GET_CONTACT_DETAILS_URL: string = '/api/contacts/get-all-contacts';
export const ADD_NEWSLETTER_SUBSCRIPTION_EMAIL_URL: string =
  '/api/newsletter/save-newsletter';
export const GET_NEWSLETTER_SUBSCRIPTION_EMAIL_URL: string =
  '/api/newsletter/get-all-email-lists';
export const GET_DASHBOARD_DETAILS_URL: string =
  '/api/dashboard/all-information';
