import { Component } from '@angular/core';

@Component({
  selector: 'app-system-admin-sidebar',
  imports: [],
  templateUrl: './system-admin-sidebar.component.html',
  styleUrl: './system-admin-sidebar.component.css'
})
export class SystemAdminSidebarComponent {

}
